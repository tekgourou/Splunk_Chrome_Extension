// content.js - Simplified version for better reliability
console.log('Splunk Quick Search content script loaded');

// Function to get the current selection
function getCurrentSelection() {
    return window.getSelection().toString().trim();
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Content script received message:', request.action);
    
    if (request.action === "getSelection") {
        const selection = getCurrentSelection();
        console.log('Sending selection to background:', selection);
        sendResponse({ selection: selection });
    } else if (request.action === "ping") {
        // Respond to ping for connection testing
        sendResponse({ success: true });
    }
    
    // Return true to indicate we'll send a response asynchronously
    return true;
});

// Log that the content script is ready
console.log('Content script ready on:', window.location.href);
