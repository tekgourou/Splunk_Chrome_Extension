// debug.js - Fixed version with correct token authentication
document.addEventListener('DOMContentLoaded', function() {
  console.log('Debug console initialized');
  
  // Add click handlers
  document.getElementById('refreshBtn').addEventListener('click', loadStorageData);
  document.getElementById('clearStorageBtn').addEventListener('click', clearStorage);
  document.getElementById('testConnectionBtn').addEventListener('click', testSplunkConnection);

  // Load initial data
  loadStorageData();
});

function loadStorageData() {
  console.log('Loading storage data');
  logToConsole('Refreshing configuration data...', 'info');
  
  chrome.storage.sync.get(null, function(data) {
    displayConfigData(data);
    showStatus('Storage data refreshed', 'success');
  });
}

function displayConfigData(data) {
  const container = document.getElementById('configDisplay');
  
  if (Object.keys(data).length === 0) {
    container.innerHTML = '<p>No configuration found</p>';
    return;
  }
  
  let html = '<table class="config-table"><tr><th>Key</th><th>Value</th></tr>';
  
  for (const [key, value] of Object.entries(data)) {
    let displayValue = value;
    
    // Mask token
    if (key === 'token' && value) {
      displayValue = value.substring(0, 10) + '...';
    }
    
    html += '<tr><td>' + escapeHTML(key) + '</td><td>' + 
            escapeHTML(String(displayValue)) + '</td></tr>';
  }
  
  html += '</table>';
  container.innerHTML = html;
}

function clearStorage() {
  if (confirm('Are you sure you want to clear all storage data?')) {
    chrome.storage.sync.clear(function() {
      loadStorageData();
      showStatus('Storage cleared', 'success');
      logToConsole('Storage cleared', 'info');
    });
  }
}

function testSplunkConnection() {
  const resultElement = document.getElementById('connectionResult');
  resultElement.innerHTML = '<div style="color: #65A637;">Testing connection...</div>';
  
  chrome.storage.sync.get(null, function(config) {
    if (!config.splunkApiUrl) {
      resultElement.innerHTML = '<div class="error">No Splunk API URL configured</div>';
      return;
    }
    
    if (!config.token) {
      resultElement.innerHTML = '<div class="error">No authentication token configured</div>';
      return;
    }
    
    // Test connection
    try {
      const apiUrl = config.splunkApiUrl.replace(/\/$/, ''); // Remove trailing slash
      const infoUrl = `${apiUrl}/services/server/info?output_mode=json`;
      
      logToConsole('Testing connection to: ' + infoUrl, 'info');
      
      // Fixed: Splunk expects "Splunk" prefix for token auth, not "Bearer"
      const authHeader = `Splunk ${config.token}`;
      
      fetch(infoUrl, {
        headers: {
          'Authorization': authHeader
        }
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('HTTP error ' + response.status);
        }
        return response.json();
      })
      .then(data => {
        logToConsole('Connection successful', 'info');
        
        let serverInfo = 'Unknown';
        if (data.entry && data.entry.length > 0 && data.entry[0].content) {
          const content = data.entry[0].content;
          serverInfo = 'Splunk ' + content.version + ' (Build: ' + content.build + ')';
        }
        
        resultElement.innerHTML = '<div class="success"><strong>Connection successful!</strong><br>Server: ' + 
          serverInfo + '<br>API URL: ' + config.splunkApiUrl + '<br>UI URL: ' + config.splunkUiUrl + '</div>';
      })
      .catch(error => {
        logToConsole('Connection failed: ' + error.message, 'error');
        
        let errorMessage = error.message;
        let suggestions = '';
        
        if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
          errorMessage = 'Network error - Unable to connect to Splunk server';
          suggestions = '<br><br><strong>Possible causes:</strong><ul>' +
            '<li>SSL certificate issues (self-signed certificate)</li>' +
            '<li>Incorrect API URL</li>' +
            '<li>Server is not running</li>' +
            '<li>Firewall blocking connection</li>' +
            '</ul>' +
            '<strong>Solutions:</strong><ul>' +
            '<li>Add certificate exception in Chrome</li>' +
            '<li>Verify server is accessible</li>' +
            '<li>Check token format (should not include "Splunk" prefix)</li>' +
            '<li>Verify token permissions</li>' +
            '</ul>';
        }
        
        resultElement.innerHTML = '<div class="error">Connection failed: ' + errorMessage + suggestions + '</div>';
      });
    } catch (error) {
      logToConsole('Error creating URL: ' + error.message, 'error');
      resultElement.innerHTML = '<div class="error">Invalid configuration: ' + error.message + '</div>';
    }
  });
}

function showStatus(message, type) {
  const statusElement = document.getElementById('statusMessage');
  statusElement.textContent = message;
  statusElement.className = 'status ' + type;
  statusElement.style.display = 'block';
  
  setTimeout(function() {
    statusElement.style.display = 'none';
  }, 3000);
}

function logToConsole(message, level = 'info') {
  const logContainer = document.getElementById('logContainer');
  const date = new Date();
  const timeString = date.toLocaleTimeString();
  
  const logEntry = document.createElement('div');
  logEntry.className = 'log-entry';
  logEntry.innerHTML = '<span class="log-time">[' + timeString + ']</span> ' +
                      '<span class="log-' + level + '">' + escapeHTML(message) + '</span>';
  
  logContainer.appendChild(logEntry);
  logContainer.scrollTop = logContainer.scrollHeight;
}

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
