// results.js - Updated version with grouped results and counts

// Function to escape HTML special characters
function escapeHTML(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Function to highlight search terms
function highlightSearchTerm(text, term) {
    if (!term || !text) return text;
    
    const escapedText = escapeHTML(String(text));
    const escapedTerm = escapeHTML(String(term));
    
    // Fixed RegExp constructor
    try {
        const regex = new RegExp('(' + escapedTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
        return escapedText.replace(regex, '<span class="highlight">$1</span>');
    } catch (e) {
        console.error('Error creating RegExp:', e);
        return escapedText;
    }
}

// Function to extract time range from search query
function extractTimeRange(searchQuery) {
    // Look for earliest= pattern in the query
    const timeRangeMatch = searchQuery.match(/earliest=([^\s]+)/);
    if (timeRangeMatch) {
        return timeRangeMatch[1];
    }
    
    // If not found, get from storage
    chrome.storage.sync.get(['timeRange'], function(result) {
        return result.timeRange || '-24h@h';
    });
}

// Function to group similar results
function groupSimilarResults(results, groupByField = null) {
    const grouped = new Map();
    
    results.forEach(result => {
        // Determine the key for grouping
        let key;
        if (groupByField && result[groupByField]) {
            key = result[groupByField];
        } else {
            // If no specific field, try to find a message-like field
            key = result.message || result._raw || result.event || JSON.stringify(result);
        }
        
        // Clean the key (remove timestamps, IDs, etc. for better grouping)
        const cleanedKey = cleanGroupingKey(key);
        
        if (grouped.has(cleanedKey)) {
            const group = grouped.get(cleanedKey);
            group.count++;
            group.instances.push(result);
        } else {
            grouped.set(cleanedKey, {
                key: key,
                cleanedKey: cleanedKey,
                count: 1,
                instances: [result],
                firstInstance: result
            });
        }
    });
    
    // Convert to array and sort by count (descending)
    return Array.from(grouped.values()).sort((a, b) => b.count - a.count);
}

// Function to clean a key for better grouping
function cleanGroupingKey(key) {
    if (typeof key !== 'string') return String(key);
    
    // Remove common patterns that make messages unique but similar
    return key
        // Remove timestamps (various formats)
        .replace(/\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(\.\d+)?([+-]\d{2}:?\d{2})?/g, 'TIMESTAMP')
        .replace(/\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/g, 'DATE')
        .replace(/\b\d{1,2}:\d{2}:\d{2}\b/g, 'TIME')
        // Remove IDs and numbers
        .replace(/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi, 'UUID')
        .replace(/\b\d+\b/g, 'NUM')
        // Remove IP addresses
        .replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, 'IP')
        // Normalize whitespace
        .replace(/\s+/g, ' ')
        .trim();
}

// Function to display grouped results
function displayGroupedResults(searchText, groupedResults) {
    const container = document.createElement('div');
    container.className = 'grouped-results';
    
    groupedResults.forEach((group, index) => {
        const groupDiv = document.createElement('div');
        groupDiv.className = 'result-group';
        
        // Group header with count
        const header = document.createElement('div');
        header.className = 'group-header';
        header.innerHTML = `
            <span class="group-count">${group.count}x</span>
            <span class="group-text">${highlightSearchTerm(group.key, searchText)}</span>
        `;
        
        // Toggle details on click
        header.addEventListener('click', () => {
            const details = groupDiv.querySelector('.group-details');
            details.style.display = details.style.display === 'none' ? 'block' : 'none';
        });
        
        groupDiv.appendChild(header);
        
        // Group details (initially hidden)
        if (group.count > 1) {
            const details = document.createElement('div');
            details.className = 'group-details';
            details.style.display = 'none';
            
            // Show sample instances
            const table = createDetailsTable(group.instances.slice(0, 5), searchText);
            details.appendChild(table);
            
            if (group.instances.length > 5) {
                const more = document.createElement('div');
                more.className = 'more-instances';
                more.textContent = `... and ${group.instances.length - 5} more instances`;
                details.appendChild(more);
            }
            
            groupDiv.appendChild(details);
        }
        
        container.appendChild(groupDiv);
    });
    
    return container;
}

// Function to create a details table for grouped instances
function createDetailsTable(instances, searchText) {
    const table = document.createElement('table');
    table.className = 'instance-details';
    
    // Get all unique fields from instances
    const fields = new Set();
    instances.forEach(instance => {
        Object.keys(instance).forEach(field => {
            if (!field.startsWith('_')) fields.add(field);
        });
    });
    
    // Create header
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    Array.from(fields).forEach(field => {
        const th = document.createElement('th');
        th.textContent = field;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // Create body
    const tbody = document.createElement('tbody');
    instances.forEach(instance => {
        const row = document.createElement('tr');
        Array.from(fields).forEach(field => {
            const td = document.createElement('td');
            td.innerHTML = highlightSearchTerm(instance[field] || '', searchText);
            row.appendChild(td);
        });
        tbody.appendChild(row);
    });
    table.appendChild(tbody);
    
    return table;
}

// Function to display search results
function displaySearchResults(searchText, searchQuery, results, totalAvailable) {
    console.log('Displaying search results');
    
    // Hide loading, show content
    document.getElementById('loading').style.display = 'none';
    document.getElementById('content').style.display = 'block';
    
    // Display search information
    document.getElementById('selectedText').textContent = searchText;
    document.getElementById('searchQuery').textContent = searchQuery;
    
    // Extract and display time range
    const timeRange = extractTimeRange(searchQuery);
    document.getElementById('timeRange').textContent = timeRange;
    
    // Set up "Open in Splunk" link
    chrome.storage.sync.get(['splunkUiUrl'], function(config) {
        if (config.splunkUiUrl) {
            const splunkUrl = config.splunkUiUrl.replace(/\/$/, ''); // Remove trailing slash
            const searchUrl = `${splunkUrl}/en-US/app/search/search?q=${encodeURIComponent(searchQuery)}`;
            
            const openInSplunkLink = document.getElementById('openInSplunk');
            openInSplunkLink.href = searchUrl;
            openInSplunkLink.addEventListener('click', function(e) {
                e.preventDefault();
                chrome.tabs.create({ url: searchUrl });
            });
        }
    });
    
    // Display results
    const resultsContainer = document.getElementById('resultsTableContainer');
    
    if (!results || !results.results || results.results.length === 0) {
        resultsContainer.innerHTML = '<div class="no-results">No results found</div>';
        document.getElementById('resultCount').textContent = '(0)';
        document.getElementById('totalResults').textContent = '0';
        return;
    }
    
    // Group similar results
    const groupedResults = groupSimilarResults(results.results);
    
    // Update result counts
    const displayedCount = results.results.length;
    const totalCount = totalAvailable || displayedCount;
    const uniqueCount = groupedResults.length;
    
    // Show counts
    document.getElementById('resultCount').textContent = `(${uniqueCount} unique patterns from ${displayedCount} events)`;
    
    if (totalCount > displayedCount) {
        document.getElementById('totalResults').textContent = `${displayedCount} of ${totalCount} (${uniqueCount} unique)`;
    } else {
        document.getElementById('totalResults').textContent = `${displayedCount} (${uniqueCount} unique)`;
    }
    
    // Display grouped results
    resultsContainer.innerHTML = '';
    const groupedDisplay = displayGroupedResults(searchText, groupedResults);
    resultsContainer.appendChild(groupedDisplay);
}

// Function to display error
function displayError(error, searchText, searchQuery) {
    console.log('Displaying error:', error);
    
    // Hide loading, show content
    document.getElementById('loading').style.display = 'none';
    document.getElementById('content').style.display = 'block';
    
    // Display search information
    if (searchText) {
        document.getElementById('selectedText').textContent = searchText;
    }
    if (searchQuery) {
        document.getElementById('searchQuery').textContent = searchQuery;
        // Extract and display time range even in error state
        const timeRange = extractTimeRange(searchQuery);
        document.getElementById('timeRange').textContent = timeRange;
    }
    
    // Show error message
    const errorElement = document.getElementById('errorMessage');
    errorElement.textContent = error;
    errorElement.style.display = 'block';
    
    // Hide results container
    document.querySelector('.results-container').style.display = 'none';
    
    // Set results count to 0
    document.getElementById('totalResults').textContent = '0';
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Received message:', request.action);
    
    if (request.action === 'showResults') {
        displaySearchResults(request.searchText, request.searchQuery, request.results, request.totalAvailable);
        sendResponse({ success: true });
    } else if (request.action === 'showError') {
        displayError(request.error, request.searchText, request.searchQuery);
        sendResponse({ success: true });
    }
    
    return true;
});

// Handle close button click
document.addEventListener('DOMContentLoaded', function() {
    console.log('Results page DOM loaded');
    
    // Add close button handler
    const closeButton = document.getElementById('closeButton');
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            window.close();
        });
    }
    
    // Also close on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            window.close();
        }
    });
    
    // Notify background script that the page is ready
    chrome.runtime.sendMessage({ 
        action: 'resultsPageReady'
    }, function(response) {
        if (chrome.runtime.lastError) {
            console.error('Error notifying background script:', chrome.runtime.lastError);
        } else {
            console.log('Background script notified');
        }
    });
});
