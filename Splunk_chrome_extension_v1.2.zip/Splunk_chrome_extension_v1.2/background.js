// background.js - Updated version without requiring tabs permission

console.log('Background script starting...');

// Create context menu when extension is installed or browser starts
chrome.runtime.onInstalled.addListener(function() {
    console.log('Extension installed/updated');
    createContextMenu();
    
    // Initialize default settings
    chrome.storage.sync.get(['splunkApiUrl'], function(result) {
        if (!result.splunkApiUrl) {
            chrome.storage.sync.set({
                splunkApiUrl: '',
                splunkUiUrl: '',
                token: '',
                searchTemplate: 'index=* "$SELECTION$"',
                timeRange: '-24h@h',
                maxResults: '1000', // Default to 1000 results
                searchHistory: []
            }, function() {
                console.log('Default settings initialized');
            });
        }
    });
});

// Also create context menu when service worker starts (for browser restart)
chrome.runtime.onStartup.addListener(function() {
    console.log('Browser started');
    createContextMenu();
});

// Function to create context menu
function createContextMenu() {
    chrome.contextMenus.removeAll(function() {
        console.log('Existing context menus removed');
        
        chrome.contextMenus.create({
            id: "searchSplunk",
            title: "Search in Splunk: '%s'",
            contexts: ["selection"]
        }, function() {
            if (chrome.runtime.lastError) {
                console.error('Context menu error:', chrome.runtime.lastError);
            } else {
                console.log('Context menu created successfully');
            }
        });
    });
}

// Function to open results in a popup window
function openResultsPopup(callback) {
    // Use fixed dimensions without screen-relative positioning
    const width = 800;
    const height = 600;
    
    // Create a popup window with the results page
    chrome.windows.create({
        url: chrome.runtime.getURL('results.html'),
        type: 'popup',
        width: width,
        height: height,
        focused: true
    }, function(window) {
        // Store the window ID in local storage for later use
        if (window) {
            chrome.storage.local.set({ resultsWindowId: window.id }, function() {
                if (callback) callback(window);
            });
        } else {
            console.error('Failed to create popup window');
            if (callback) callback(null);
        }
    });
}

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(function(info, tab) {
    if (info.menuItemId === "searchSplunk" && info.selectionText) {
        const selectedText = info.selectionText;
        console.log('Context menu clicked, selected text:', selectedText);
        
        // Get search settings
        chrome.storage.sync.get(['searchTemplate', 'timeRange'], function(settings) {
            const searchTemplate = settings.searchTemplate || 'index=* "$SELECTION$"';
            const timeRange = settings.timeRange || '-24h@h';
            
            // Create search query
            const searchQuery = searchTemplate.replace('$SELECTION$', selectedText);
            const fullQuery = `${searchQuery} earliest=${timeRange}`;
            
            console.log('Executing search query:', fullQuery);
            
            // Execute Splunk search
            executeSplunkSearch(fullQuery, selectedText, function(result) {
                // Store search results in local storage to pass to results page
                chrome.storage.local.set({
                    searchResults: {
                        error: result.error || null,
                        data: result.data || null,
                        searchText: selectedText,
                        searchQuery: fullQuery,
                        totalAvailable: result.totalAvailable || 0,
                        timestamp: Date.now()
                    }
                }, function() {
                    // Open popup window after data is stored
                    openResultsPopup();
                });
            });
        });
    }
});

// Function to execute Splunk search with configurable result limit
async function executeSplunkSearch(searchQuery, searchText, callback) {
    try {
        // Get Splunk configuration from storage
        const config = await chrome.storage.sync.get([
            'splunkApiUrl', 
            'token',
            'maxResults'
        ]);
        
        if (!config.splunkApiUrl) {
            callback({ error: 'Splunk API URL not configured. Please set up the extension.' });
            return;
        }
        
        if (!config.token) {
            callback({ error: 'Authentication token not configured. Please set up the extension.' });
            return;
        }
        
        // Get max results (default to 1000 if not set)
        const maxResults = parseInt(config.maxResults) || 1000;
        
        // Ensure the API URL ends without a trailing slash
        const apiUrl = config.splunkApiUrl.replace(/\/$/, '');
        
        // Create search job
        const searchEndpoint = `${apiUrl}/services/search/jobs`;
        
        console.log('Creating search job at:', searchEndpoint);
        
        const formData = new URLSearchParams();
        formData.append('search', `search ${searchQuery}`);
        formData.append('output_mode', 'json');
        formData.append('max_count', maxResults.toString()); // Set max results for the job
        
        // Fixed: Splunk expects "Splunk" prefix for token auth, not "Bearer"
        const authHeader = `Splunk ${config.token}`;
        
        const createJobResponse = await fetch(searchEndpoint, {
            method: 'POST',
            headers: {
                'Authorization': authHeader,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: formData.toString()
        });
        
        if (!createJobResponse.ok) {
            const errorText = await createJobResponse.text();
            console.error('Create job failed:', createJobResponse.status, errorText);
            
            // Try to parse error message from Splunk response
            let errorMessage = `HTTP error! status: ${createJobResponse.status}`;
            try {
                const errorData = JSON.parse(errorText);
                if (errorData.messages && errorData.messages.length > 0) {
                    errorMessage = errorData.messages[0].text;
                }
            } catch (e) {
                // If parsing fails, use the default error message
            }
            
            if (createJobResponse.status === 401) {
                throw new Error('Authentication failed. Please check your token.');
            } else if (createJobResponse.status === 404) {
                throw new Error('Splunk endpoint not found. Please check your API URL.');
            }
            throw new Error(errorMessage);
        }
        
        const jobData = await createJobResponse.json();
        const jobId = jobData.sid;
        
        if (!jobId) {
            throw new Error('Failed to create search job - no SID returned');
        }
        
        console.log('Search job created:', jobId);
        
        // Wait for job to complete and get results
        const results = await waitForJobAndGetResults(apiUrl, jobId, authHeader, maxResults);
        callback({ success: true, data: results.data, totalAvailable: results.totalAvailable });
        
    } catch (error) {
        console.error('Error executing Splunk search:', error);
        
        if (error.message.includes('SSL') || error.message.includes('certificate')) {
            callback({ 
                error: 'SSL certificate error. Please add a certificate exception in Chrome or contact your administrator.' 
            });
        } else if (error.message === 'Failed to fetch') {
            callback({ 
                error: 'Network error: Unable to connect to Splunk server. Please check your API URL.' 
            });
        } else {
            callback({ error: error.message });
        }
    }
}

// Function to wait for job completion and get results
async function waitForJobAndGetResults(baseUrl, jobId, authHeader, maxResults) {
    const jobStatusUrl = `${baseUrl}/services/search/jobs/${jobId}?output_mode=json`;
    const maxAttempts = 60; // 30 seconds max wait time
    let attempts = 0;
    
    while (attempts < maxAttempts) {
        const statusResponse = await fetch(jobStatusUrl, {
            headers: { 'Authorization': authHeader }
        });
        
        if (!statusResponse.ok) {
            throw new Error(`Failed to check job status: ${statusResponse.status}`);
        }
        
        const statusData = await statusResponse.json();
        const jobStatus = statusData.entry[0].content;
        
        console.log(`Job ${jobId} status:`, jobStatus.dispatchState);
        
        if (jobStatus.isDone) {
            // Get total available results
            const totalAvailable = jobStatus.resultCount || 0;
            
            // Get results with configurable limit
            const resultsUrl = `${baseUrl}/services/search/jobs/${jobId}/results?output_mode=json&count=${maxResults}`;
            const resultsResponse = await fetch(resultsUrl, {
                headers: { 'Authorization': authHeader }
            });
            
            if (!resultsResponse.ok) {
                throw new Error(`Failed to get results: ${resultsResponse.status}`);
            }
            
            const resultsData = await resultsResponse.json();
            return {
                data: resultsData,
                totalAvailable: totalAvailable
            };
        }
        
        // Wait before next check
        await new Promise(resolve => setTimeout(resolve, 500));
        attempts++;
    }
    
    throw new Error('Search job timed out');
}

// Message listener for popup and other parts of the extension
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'searchSplunk') {
        executeSplunkSearch(request.query, request.searchText, function(result) {
            sendResponse(result);
        });
        return true; // Will respond asynchronously
    }
    
    if (request.action === 'configUpdated') {
        console.log('Configuration updated, recreating context menu');
        createContextMenu();
        sendResponse({ success: true });
    }
    
    if (request.action === 'getSearchResults') {
        // Send back the stored search results
        chrome.storage.local.get('searchResults', function(data) {
            if (data.searchResults) {
                sendResponse(data.searchResults);
            } else {
                sendResponse({ error: 'No search results found' });
            }
        });
        return true; // Will respond asynchronously
    }
    
    return false;
});

// Handle window close events to clean up storage
chrome.windows.onRemoved.addListener(function(windowId) {
    chrome.storage.local.get('resultsWindowId', function(data) {
        if (data.resultsWindowId === windowId) {
            chrome.storage.local.remove('resultsWindowId');
        }
    });
});

console.log('Background script loaded');