// popup.js - Updated version with max results handling
document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup initialized');
  
  // Load saved configuration
  chrome.storage.sync.get([
    'splunkApiUrl',
    'splunkUiUrl',
    'token',
    'searchTemplate',
    'timeRange',
    'maxResults'
  ], function(result) {
    console.log('Configuration loaded');
    
    // Populate form fields
    document.getElementById('splunkApiUrl').value = result.splunkApiUrl || '';
    document.getElementById('splunkUiUrl').value = result.splunkUiUrl || '';
    document.getElementById('token').value = result.token || '';
    document.getElementById('searchTemplate').value = result.searchTemplate || 'index=* $SELECTION$';
    document.getElementById('timeRange').value = result.timeRange || '-24h@h';
    document.getElementById('maxResults').value = result.maxResults || '1000';
  });
  
  // Save button click handler
  document.getElementById('saveButton').addEventListener('click', function() {
    const splunkApiUrl = document.getElementById('splunkApiUrl').value.trim();
    const splunkUiUrl = document.getElementById('splunkUiUrl').value.trim();
    const token = document.getElementById('token').value.trim();
    const searchTemplate = document.getElementById('searchTemplate').value.trim();
    const timeRange = document.getElementById('timeRange').value.trim();
    const maxResults = document.getElementById('maxResults').value.trim();
    
    // Validate API URL
    if (!splunkApiUrl) {
      showStatus('Please enter a valid Splunk API URL', 'error');
      return;
    }
    
    // Validate UI URL
    if (!splunkUiUrl) {
      showStatus('Please enter a valid Splunk UI URL', 'error');
      return;
    }
    
    // Validate URL format
    try {
      new URL(splunkApiUrl);
      new URL(splunkUiUrl);
    } catch (e) {
      showStatus('Please enter valid URLs', 'error');
      return;
    }
    
    // Validate token
    if (!token) {
      showStatus('Please enter an authentication token', 'error');
      return;
    }
    
    // Validate max results
    const maxResultsNum = parseInt(maxResults);
    if (isNaN(maxResultsNum) || maxResultsNum < 1 || maxResultsNum > 50000) {
      showStatus('Max results must be between 1 and 50,000', 'error');
      return;
    }
    
    // Configuration object to save
    const config = {
      splunkApiUrl: splunkApiUrl,
      splunkUiUrl: splunkUiUrl,
      token: token,
      searchTemplate: searchTemplate || 'index=* $SELECTION$',
      timeRange: timeRange || '-24h@h',
      maxResults: maxResults || '1000'
    };
    
    // Save configuration
    chrome.storage.sync.set(config, function() {
      console.log('Configuration saved');
      showStatus('Configuration saved successfully!', 'success');
      
      // Notify background script
      chrome.runtime.sendMessage({ action: 'configUpdated' });
    });
  });
  
  // Debug link handler
  document.getElementById('debugLink').addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('debug.html') });
  });
  
  function showStatus(message, type) {
    const statusElement = document.getElementById('statusMessage');
    statusElement.textContent = message;
    statusElement.className = 'status ' + type;
    statusElement.style.display = 'block';
    
    setTimeout(function() {
      statusElement.style.display = 'none';
    }, 3000);
  }
});
